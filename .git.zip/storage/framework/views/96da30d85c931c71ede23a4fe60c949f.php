<?php $__env->startSection('content'); ?>
<div class="container-xxl flex-grow-1 container-p-y">
    <h4 class="fw-bold py-3 mb-4"><span class="text-muted fw-light"></span> Pricing Section</h4>

    <?php if(session('success')): ?>
    <div class="alert alert-success alert-dismissible fade show" role="alert">
        <?php echo e(session('success')); ?>

        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
    </div>
    <?php endif; ?>

    <div class="card">
        <div class="card-header d-flex justify-content-between align-items-center">
            <h5 class="mb-0">Kelola Paket Pricing</h5>
            <small class="text-muted">Klik edit pada paket yang ingin diubah</small>
        </div>
        <div class="table-responsive text-nowrap">
            <table class="table table-hover">
                <thead>
                    <tr>
                        <th>Icon</th>
                        <th>Nama Paket</th>
                        <th>Harga</th>
                        <th>Aksi</th>
                    </tr>
                </thead>
                <tbody class="table-border-bottom-0">
                    <?php $__empty_1 = true; $__currentLoopData = $pricings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td>
                            <?php if($item->icon): ?>
                                <img src="<?php echo e(asset('storage/' . $item->icon)); ?>" width="30" class="rounded shadow-sm">
                            <?php else: ?>
                                <span class="badge bg-label-secondary">No Icon</span>
                            <?php endif; ?>
                        </td>
                        <td><strong><?php echo e($item->nama_paket); ?></strong></td>
                        <td><?php echo e($item->harga_lengkap); ?></td>
                        <td>
                            
                            <a href="<?php echo e(route('admin.pricing.edit', $item->id)); ?>" class="btn btn-sm btn-primary">
                                <i class="bx bx-edit-alt me-1"></i> Edit
                            </a>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan="4" class="text-center">Data paket tidak ditemukan.</td>
                    </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\rapiin\resources\views/admin/pricing/index.blade.php ENDPATH**/ ?>