<?php $__env->startSection('content'); ?>
<div class="container-xxl flex-grow-1 container-p-y">

    <div class="card mb-4">
        <div class="card-header d-flex align-items-center justify-content-between">
            <h5 class="mb-0"><?php echo e(isset($footer) ? 'Edit Footer' : 'Tambah Footer'); ?></h5>
        </div>

        <div class="card-body">
            <form action="<?php echo e(isset($footer) ? route('footer.update', $footer) : route('footer.store')); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <?php if(isset($footer)): ?> <?php echo method_field('PUT'); ?> <?php endif; ?>

                <?php
                    $fields = [
                        'facebook' => 'Facebook',
                        'instagram' => 'Instagram',
                        'twitter' => 'Twitter',
                        'linkedin' => 'LinkedIn',
                        'whatsapp' => 'WhatsApp',
                        'tiktok' => 'TikTok',
                        'email' => 'Email',
                        'kontak' => 'Kontak',
                    ];
                ?>

                
                <div class="card mb-4 border">
                    <div class="card-header">
                        <h6 class="mb-0">Social Media & Kontak</h6>
                    </div>

                    <div class="card-body">
                        <?php $__currentLoopData = $fields; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $name => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="row mb-3">
                            <label class="col-sm-2 col-form-label" for="<?php echo e($name); ?>"><?php echo e($label); ?></label>

                            <div class="col-sm-10">
                                <input type="text"
                                    class="form-control <?php $__errorArgs = [$name];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                    id="<?php echo e($name); ?>"
                                    name="<?php echo e($name); ?>"
                                    placeholder="Input <?php echo e($label); ?>"
                                    value="<?php echo e(old($name, $footer->$name ?? '')); ?>">

                                <?php $__errorArgs = [$name];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>

                
                <div class="card mb-4 border">
                    <div class="card-header">
                        <h6 class="mb-0">Alamat Perusahaan</h6>
                    </div>

                    <div class="card-body">
                        <div class="row">
                            <label class="col-sm-2 col-form-label" for="alamat">Alamat</label>

                            <div class="col-sm-10">
                                <textarea
                                    class="form-control <?php $__errorArgs = ['alamat'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                    name="alamat"
                                    id="alamat"
                                    rows="3"
                                    placeholder="Input Alamat Lengkap"><?php echo e(old('alamat', $footer->alamat ?? '')); ?></textarea>
                            </div>
                        </div>
                    </div>
                </div>

                
                <div class="row justify-content-end mt-4">
                    <div class="col-sm-10">
                        <button type="submit" class="btn btn-primary">
                            <i class="bx bx-send me-1"></i> Send
                        </button>

                        <a class="btn btn-outline-secondary" href="<?php echo e(route('footer.index')); ?>">
                            Back
                        </a>
                    </div>
                </div>

            </form>
        </div>
    </div>

</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\rapiin\resources\views/footer/edit.blade.php ENDPATH**/ ?>