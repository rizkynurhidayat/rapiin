<?php $__env->startSection('content'); ?>

<style>
.box-link{
    width:90px;
    min-height:120px;
    border:1px solid #ddd;
    border-radius:8px;
    padding:6px;
    font-size:12px;
    background:#f9f9f9;
    word-break:break-word;
}
</style>

<div class="container-xxl flex-grow-1 container-p-y">

    <h4 class="fw-bold py-3 mb-4">
        <span class="text-muted fw-light"></span> Footer Data
    </h4>

    <?php if(session('success')): ?>
        <div class="alert alert-success alert-dismissible fade show">
            <?php echo e(session('success')); ?>

            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    <?php endif; ?>

    <div class="card">

        <div class="card-header d-flex justify-content-between align-items-center">
            <h5 class="mb-0">Kelola Footer </h5>
        </div>

        <div class="table-responsive">
            <table class="table table-hover align-middle">

                <thead>
                    <tr>
                        <th>Facebook</th>
                        <th>Instagram</th>
                        <th>Twitter</th>
                        <th>LinkedIn</th>
                        <th>WhatsApp</th>
                        <th>TikTok</th>
                        <th>Email</th>
                        <th>Kontak</th>
                        <th>Alamat</th>
                        <th>Actions</th>
                    </tr>
                </thead>

                <tbody class="table-border-bottom-0">

                    <?php $__empty_1 = true; $__currentLoopData = $footers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $footer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>

                        <tr>

                            <td>
                                <div class="box-link">
                                    <?php echo e(Str::limit($footer->facebook, 50)); ?>

                                </div>
                            </td>

                            <td>
                                <div class="box-link">
                                    <?php echo e(Str::limit($footer->instagram, 50)); ?>

                                </div>
                            </td>

                            <td>
                                <div class="box-link">
                                    <?php echo e(Str::limit($footer->twitter, 50)); ?>

                                </div>
                            </td>

                            <td>
                                <div class="box-link">
                                    <?php echo e(Str::limit($footer->linkedin, 50)); ?>

                                </div>
                            </td>

                            <td>
                                <div class="box-link">
                                    <?php echo e(Str::limit($footer->whatsapp, 50)); ?>

                                </div>
                            </td>

                            <td>
                                <div class="box-link">
                                    <?php echo e(Str::limit($footer->tiktok, 50)); ?>

                                </div>
                            </td>

                            <td>
                                <div class="box-link">
                                    <?php echo e($footer->email); ?>

                                </div>
                            </td>

                            <td>
                                <div class="box-link">
                                    <?php echo e($footer->kontak); ?>

                                </div>
                            </td>

                            <td>
                                <div class="box-link">
                                    <?php echo e(Str::limit($footer->alamat, 60)); ?>

                                </div>
                            </td>

                            <td>

                                <a href="<?php echo e(route('footer.edit', $footer)); ?>"
                                   class="btn btn-sm btn-primary">
                                    <i class="bx bx-edit-alt"></i> Edit
                                </a>

                            </td>

                        </tr>

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>

                        <tr>
                            <td colspan="10" class="text-center">
                                Data footer tidak ditemukan
                            </td>
                        </tr>

                    <?php endif; ?>

                </tbody>

            </table>
        </div>

    </div>

</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\rapiin\resources\views/footer/index.blade.php ENDPATH**/ ?>