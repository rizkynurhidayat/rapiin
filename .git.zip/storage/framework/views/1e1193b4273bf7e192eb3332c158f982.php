<?php echo $__env->make('component.popup', ['pricings' => $pricings], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>POS RAPIIN KELOMPOK 3 | Techade</title>
  <link rel="stylesheet" href="<?php echo e(asset('rapiin')); ?>/style.css">
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Inter:ital,opsz,wght@0,14..32,500;1,14..32,500&family=Poppins:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&display=swap" rel="stylesheet">
</head>
<body>
  

<!-- Navbar -->
<section id="Beranda">
<nav class="nav">
  <img src="<?php echo e(asset ('rapiin')); ?>/icon/image 23.png" alt="Techade" class="logo">
  <div>
  <ul class="nav-menu">
    <li><a href="#Beranda" class="active">Beranda</a></li>
    <li><a href="#Fitur">Fitur</a></li>
    <li><a href="#Demo">Demo</a></li>
    <li><a href="#Paket">Paket</a></li>
  </ul>
  </div>
  
  <button class="btn-nav" onclick="openPopup()">Mulai</button>
  <div class="menu">
    <svg xmlns="http://www.w3.org/2000/svg" height="24px" viewBox="0 -960 960 960" width="24px" fill="#e3e3e3"><path d="M120-240v-80h720v80H120Zm0-200v-80h720v80H120Zm0-200v-80h720v80H120Z"/></svg>
  </div>
</nav>
</section>
<!-- navbar mobile -->
 <section>
 <div class="mob-nav">
 <div class="side-header">
  <img src="<?php echo e(asset ('rapiin')); ?>/icon/image 23.png" class="side-logo">
 </div>
  <ul class="side-menu">
    <li><a href="#Beranda"><img src="<?php echo e(asset ('rapiin')); ?>/icon/lets-icons_home-fill.png"><span>Beranda</span></a></li>
    <li><a href="#Fitur"><img src="<?php echo e(asset ('rapiin')); ?>/icon/mingcute_google-gemini-line.png"><span>Fitur</span></a></li>
    <li><a href="#Demo"><img src="<?php echo e(asset ('rapiin')); ?>/icon/mingcute_video-line.png"><span>Demo</span></a></li>
    <li><a href="#Paket"><img src="<?php echo e(asset ('rapiin')); ?>/icon/ph_money-wavy.png"><span>Paket</span></a></li>
  </ul>
  </div>
</div>
  </section>
<!-- Navbar END -->
<!-- Hero -->
<section class="hero fade-scroll">
  <div class="hero-text">
    <?php if($hero): ?>
      <h2 class="poppins-semibold">
        <?php echo e($hero->judul_awal); ?> 
        <br>
        <span class="highlight"><?php echo e($hero->highlight_text); ?></span> 
        <?php echo e($hero->judul_akhir); ?>

      </h2>
      
     <button class="btn-hero" onclick="openPopup()"><?php echo e($hero->button); ?></button>
    <?php endif; ?>
  </div>
  
  <?php if($hero && $hero->image): ?>
    <img src="<?php echo e(str_contains($hero->image, 'hero/') ? asset('storage/' . $hero->image) : asset($hero->image)); ?>" class="hero-img">
  <?php endif; ?>
</section>
<!-- Hero END -->
<!-- Fitur -->
<section id="Fitur" class="fitur fade-scroll" >
  <h1 class="fitur-title">
    Fitur-fitur POS <span class="highlight">RAPIIN</span>
  </h1>

  <div class="card-fitur">
    <div class="card">
      <img src="<?php echo e(asset ('rapiin')); ?>/icon/openmoji_bar-chart.png" alt="Card Laporan Real-Time">
      <h3 class="poppins-semibold">Laporan Real-Time</h3>
      <p class="inter-uniquifier">Pantau penjualan, laba, dan transaksi harian secara langsung tanpa menunggu rekap manual.</p>
    </div>

    <div class="card">
      <img src="<?php echo e(asset ('rapiin')); ?>/icon/icon-park_box.png" alt="Card Manajemen Stok ">
      <h3 class="poppins-semibold">Manajemen Stok</h3>
      <p class="inter-uniquifier">Stok barang otomatis berkurang saat transaksi, minim salah hitung dan kehabisan barang.</p>
    </div>

    <div class="card">
      <img src="<?php echo e(asset ('rapiin')); ?>/icon/emojione_bank.png" alt="Integrasi Bank ">
      <h3 class="poppins-semibold">Integrasi Bank</h3>
      <p class="inter-uniquifier">Terhubung dengan pembayaran non-tunai dan mutasi bank untuk pencatatan yang lebih rapi.</p>
    </div>
  </div>
</section>
<!-- Fitur END -->
<!-- Demo -->
<section id="Demo" class="perbandingan fade-scroll">
  <h1 class="judul">Perbandingan Sistem Kasir</h1>
  
  <div class="perbandingan-grid">
    <div class="item-wrapper">
      <img src="<?php echo e(asset ('rapiin')); ?>/foto/image 24.png" class="img-banding">
    </div>
    <div class="item-wrapper">
      <div class="card banding manual">
        <span class="judul-badge putih">Metode Kasir Manual</span>
        <ul class="inter-uniquifier">
          <li>Lama dan Antrian panjang</li>
          <li>Manual & Tidak Akurat</li>
          <li>Rumit & Tertunda</li>
          <li>Terbatas (Di Lokasi Saja)</li>
        </ul>
      </div>
    </div>

    <div class="item-wrapper">
      <div class="card banding digital">
        <span class="judul-badge biru">Sistem POS Digital</span>
        <ul class="inter-uniquifier">
          <li>Cepat & Tanpa Antrian</li>
          <li>Otomatis & Real-Time</li>
          <li>Instan & Komprehensif</li>
          <li>Fleksibel (Dimana Saja)</li>
        </ul>
      </div>
    </div>
    <div class="item-wrapper">
      <img src="<?php echo e(asset ('rapiin')); ?>/foto/image 25.png" class="img-banding">
    </div>
  </div>

  <div class="demo">
      <h1>Bagaimana <span class="highlight">RAPIIN</span> POS Membantu Operasional Bisnis?</h1>
      <iframe 
        width="900"
        height="500"
        src="https://www.youtube.com/embed/PtM2B1vLVbI"
        title="Demo RapIIN POS"
        frameborder="0"
        allowfullscreen>
      </iframe>
  </div>
</section>
<!-- Demo END -->
<!-- Paket -->
<section id="Paket" class="pricing-section fade-scroll">
    
    
    <?php if($pricings->isNotEmpty()): ?>
        <div class="header-content">
            <h1>
                <?php echo e($pricings->first()->section_judul_awal); ?> 
                <span class="cyan"><?php echo e($pricings->first()->section_highlight_text); ?></span> 
                <?php echo e($pricings->first()->section_judul_akhir); ?>

            </h1>
            <p><?php echo e($pricings->first()->section_sub_judul); ?></p>
        </div>
    <?php endif; ?>

    
    <div class="flex-wrapper">
        
        
        <?php $__currentLoopData = $pricings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="card <?php echo e($item->icon ? 'active' : ''); ?>">
                
                <?php if($item->icon): ?>
                    <div class="crown">
                        <?php if(Str::contains($item->icon, ['/', '.'])): ?>
                            <img src="<?php echo e(asset('storage/' . $item->icon)); ?>" width="60">
                        <?php else: ?>
                            <?php echo e($item->icon); ?>

                        <?php endif; ?>
                    </div>
                    <div class="best-seller">
                        <h4>Best Seller</h4>
                    </div>
                <?php endif; ?>

                <div class="tag-box">
                    <h5><?php echo e(strtoupper($item->nama_paket)); ?></h5>
                </div>
                
                
                <p class="card-desc" style="text-align: left; width: 100%;">
                    <?php echo e($item->deskripsi); ?>

                </p>
                
                <h2 class="card-price"><?php echo e($item->harga_lengkap); ?></h2>
                
                <button class="card-button" onclick="openPopup(<?php echo e($index); ?>)"><?php echo e($item->teks_button); ?></button>
                
                
                <ul class="card-features">
                    <?php $__currentLoopData = explode(',', $item->fitur); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $feature): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if(trim($feature) !== ""): ?>
                            <li><?php echo e(trim($feature)); ?></li>
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
                
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    </div>
</section>
          
            
<!-- Paket END -->
<!-- Footer -->
<footer id="footer">
  <div class="footer-container">
    <div class="footer-content">
      <!-- Brand Info -->
      <div class="footer-col brand-info">
        <img src="<?php echo e(asset('rapiin/icon/image 23.png')); ?>" alt="logo techade" class="footer-logo">
        <p style="font-size: 14px; line-height: 1.8; color: white; max-width: 400px;">
          Solusi point of sale untuk mengelola operasional bisnis secara lebih mudah dan terstruktur.
        </p>
        <div class="social-icons">
          <img src="<?php echo e(asset('rapiin/icon/gg_facebook.png')); ?>" alt="facebook" 
               onclick="window.location.href='<?php echo e(!empty($footer->facebook) ? $footer->facebook : 'https://www.facebook.com/profile.php?id=61556979945239&mibextid=LQQJ4d'); ?>'"style="cursor: pointer;" >
          <img src="<?php echo e(asset('rapiin/icon/mdi_instagram.png')); ?>" alt="instagram" 
               onclick="window.location.href='<?php echo e(!empty($footer->instagram) ? $footer->instagram : 'https://www.instagram.com/techade.id/'); ?>'"style="cursor: pointer;">
          <img src="<?php echo e(asset('rapiin/icon/Clip path group.png')); ?>" alt="twitter" 
               onclick="window.location.href='<?php echo e(!empty($footer->twitter) ? $footer->twitter : 'https://www.x.com/techade_id'); ?>'" style="cursor: pointer;">
          <img src="<?php echo e(asset('rapiin/icon/ri_linkedin-fill.png')); ?>" alt="linkedin" 
               onclick="window.location.href='<?php echo e(!empty($footer->linkedin) ? $footer->linkedin : 'https://www.linkedin.com/company/techade-id?originalSubdomain=id'); ?>'" style="cursor: pointer;">
          <img src="<?php echo e(asset('rapiin/icon/ic_baseline-whatsapp.png')); ?>" alt="whatsapp" 
               onclick="window.location.href='https://wa.me/<?php echo e(preg_replace('/[^0-9]/', '', !empty($footer->whatsapp) ? $footer->whatsapp : '6287812066967')); ?>'" style="cursor: pointer;">
          <img src="<?php echo e(asset('rapiin/icon/mingcute_tiktok-fill.png')); ?>" alt="tiktok" 
               onclick="window.location.href='<?php echo e(!empty($footer->tiktok) ? $footer->tiktok : 'https://www.tiktok.com/@techade.id?_r=1&_t=ZS-94YoxxiMU4e'); ?>'" style="cursor: pointer;">
        </div>
      </div>

      <!-- Navigasi -->
      <div class="footer-col">
        <h3>Navigasi</h3>
        <ul>
          <li onclick="window.location.href='https://techade.id/#services'" style="cursor: pointer;">Servis</li>
          <li onclick="window.location.href='https://techade.id/#portfolio'" style="cursor: pointer;">Portofolio</li>
          <li onclick="window.location.href='https://techade.id/#keunggulan'" style="cursor: pointer;">Keunggulan</li>
        </ul>
      </div>

      <!-- Hubungi Kami -->
      <div class="footer-col contact-col">
        <h3>Hubungi Kami</h3>
        <ul>
          <li onclick="window.location.href='mailto:<?php echo e(!empty($footer->email) ? $footer->email : 'contact@techade.id'); ?>'" style="cursor: pointer;">
            <img src="<?php echo e(asset('rapiin/icon/ic_round-email.png')); ?>" class="icon"> 
            <span><?php echo e(!empty($footer->email) ? $footer->email : 'contact@techade.id'); ?></span>
          </li>  
          <li onclick="window.location.href='https://wa.me/<?php echo e(preg_replace('/[^0-9]/', '', !empty($footer->kontak) ? $footer->kontak : '6287812066967')); ?>'" style="cursor: pointer;">
            <img src="<?php echo e(asset('rapiin/icon/mingcute_phone-fill.png')); ?>" class="icon"> 
            <span><?php echo e(!empty($footer->kontak) ? $footer->kontak : '+6287812066967'); ?></span>
          </li>
          <li class="address" onclick="window.location.href='https://www.google.com/maps/search/?api=1&query=<?php echo e(urlencode(!empty($footer->alamat) ? $footer->alamat : 'Palm Asri 2 Blk. G No.16, Mejen, Pedagangan, Kec. Dukuhwaru, Kabupaten Tegal, Jawa Tengah 52451')); ?>'" style="cursor: pointer;">
            <img src="<?php echo e(asset('rapiin/icon/mdi_address-marker (1).png')); ?>" class="icon">
            <span><?php echo e(!empty($footer->alamat) ? $footer->alamat : 'Palm Asri 2 Blk. G No.16, Mejen, Pedagangan, Kec. Dukuhwaru, Kabupaten Tegal, Jawa Tengah 52451'); ?></span>
          </li>
        </ul>
      </div>

      <!-- Perusahaan -->
      <div class="footer-col">
        <h3>Perusahaan</h3>
        <ul>
          <li onclick="window.location.href='https://techade.id/about'" style="cursor: pointer;">Tentang Kami</li>
          <li onclick="window.location.href='https://techade.id/products'" style="cursor: pointer;">Produk</li>
        </ul>
      </div>
    </div>

    <!-- Footer Bottom -->
    <div class="footer-bottom">
      <hr>
      <p>© 2025 | Techade.id Seluruh Hak Cipta Dilindungi</p>
    </div>
  </div>
</footer>
<!-- Footer END -->     
 <script src="<?php echo e(asset('rapiin/belajar.js')); ?>"></script>   
</body>
</body>
</html><?php /**PATH C:\laragon\rapiin\resources\views/index.blade.php ENDPATH**/ ?>