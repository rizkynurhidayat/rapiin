<?php $__env->startSection('content'); ?>

<div class="container-xxl flex-grow-1 container-p-y">

    <h4 class="fw-bold py-3 mb-4">
        <span class="text-muted fw-light"></span> Users Data
    </h4>

    <div class="card">

        <div class="card-header d-flex justify-content-between align-items-center">
            <h5 class="mb-0">Kelola Users</h5>
        </div>

        <div class="table-responsive text-nowrap">

            <table class="table table-hover align-middle">

                <thead>
                    <tr>
                        <th>Name</th>
                        <th>Email</th>
                        <th>Status</th>
                        <th>Actions</th>
                    </tr>
                </thead>

                <tbody class="table-border-bottom-0">

                    <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>

                        <td>
                            <strong><?php echo e($user->name); ?></strong>
                        </td>

                        <td>
                            <?php echo e($user->email); ?>

                        </td>

                        <td>
                            <span class="badge bg-label-primary">
                                Admin
                            </span>
                        </td>

                        <td>
                            <!-- Tombol Edit -->
                            <a href="<?php echo e(route('users.edit', $user)); ?>" 
                               class="btn btn-sm btn-primary me-1">
                                <i class="bx bx-edit-alt"></i> Edit
                            </a>

                            <!-- Tombol Delete -->
                            <form action="<?php echo e(route('users.destroy', $user)); ?>" method="POST" class="d-inline"
                                  onsubmit="return confirm('Yakin ingin menghapus user ini?')">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <button type="submit" class="btn btn-sm btn-danger">
                                    <i class="bx bx-trash"></i> Delete
                                </button>
                            </form>
                        </td>

                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </tbody>

            </table>

        </div>

    </div>

</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\rapiin\resources\views/users/index.blade.php ENDPATH**/ ?>